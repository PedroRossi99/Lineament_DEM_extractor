[readme.txt](https://github.com/PedroRossi99/SRTM_lineament_finder/files/14409826/readme.txt)
